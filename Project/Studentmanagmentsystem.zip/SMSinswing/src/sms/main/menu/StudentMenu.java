package sms.main.menu;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.event.MenuListener;

import sms.main.Login;

import javax.swing.event.MenuEvent;

public class StudentMenu extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	
	public StudentMenu() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setTitle("Student Menu");
		setVisible(true);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("View Instructors");
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("View Courses");
		menuBar.add(mnNewMenu_1);
		
		JMenu mnNewMenu_2 = new JMenu("View Student By Id");
		menuBar.add(mnNewMenu_2);
		
		JMenu mnNewMenu_3 = new JMenu("View Feedback By Student Id");
		menuBar.add(mnNewMenu_3);
		
		JMenu mnNewMenu_4 = new JMenu("Add Feedback");
		menuBar.add(mnNewMenu_4);
		
		JMenu mnNewMenu_5 = new JMenu("View Score");
		menuBar.add(mnNewMenu_5);
		
		JMenu mnNewMenu_6 = new JMenu("Logout");
		mnNewMenu_6.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}
			public void menuDeselected(MenuEvent e) {
			}
			public void menuSelected(MenuEvent e) {
				JOptionPane.showMessageDialog(contentPane,"You are successfully logout.");
			    dispose();
				new Login();
			}
		});
		menuBar.add(mnNewMenu_6);
		setContentPane(contentPane);
	}

}
