package sms.main.operation;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import sms.main.DAO.CourseDAO;
import sms.main.menu.AdminMenu;
import sms.main.model.Course;
import sms.main.DAO.ScoreDAO;
import sms.main.model.Score;

import javax.swing.JFormattedTextField;

public class ScoreOperation extends JFrame {

	private JTable table;
	DefaultTableModel model;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JFormattedTextField formattedTextField;
	public ScoreOperation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10, 10, 800, 500);
		setVisible(true);

		JPanel panel = new JPanel();
		panel.setBounds(5, 400, 780, 60);
		panel.setBorder(new LineBorder(SystemColor.textHighlight, 5));
		
		getContentPane().add(panel);
		
		JButton btnNewButton_5 = new JButton("Add Score");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String scoreID=textField.getText();
				String studentID=textField_1.getText();
				String courseID=textField_2.getText();
				String creditObtained=textField_3.getText();
				String dateOfExamStr=formattedTextField.getText();
				 Score obj = new Score(scoreID, studentID, courseID, creditObtained, dateOfExamStr);

			        // Calling method to insert into table and passing the object of Score class
			        boolean result = ScoreDAO.insert(obj);
			      	        if (result) {
		        	JOptionPane.showMessageDialog(getContentPane()," The Score is successfully added.");
		           // System.out.println("To continue follow the steps...");
		        } else {
		        	JOptionPane.showMessageDialog(getContentPane(),"Something went wrong.");
		        }
			}
		});
		panel.add(btnNewButton_5);
		
		JButton btnNewButton = new JButton("Update Score");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String scoreID=textField.getText();
				String studentID=textField_1.getText();
				String courseID=textField_2.getText();
				String creditObtained=textField_3.getText();
				String dateOfExamStr=formattedTextField.getText();
				 Score obj = new Score(scoreID, studentID, courseID, creditObtained, dateOfExamStr);

			        // Calling method to update the record in the table
			        boolean result = ScoreDAO.update(obj, scoreID);
			               if (result) {                        
			        	JOptionPane.showMessageDialog(getContentPane(),"The score is successfully updated.");
			        } else {
			        	JOptionPane.showMessageDialog(getContentPane(),"Something went wrong.");
			        }  
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.TOP);
		
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("View All Score");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//table.clearSelection();
				model.setRowCount(0);
				List<Score> scores = ScoreDAO.getAllScores();
		        for (Score score : scores) {
		         	//System.out.println(course);
		        	model.addRow(new Object[] {score.getScoreID(),score.getStudentID(),score.getCourseID(),score.getCreditObtained(),score.getDateOfExam()});
		        }
			}
		});
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("View Score By Id");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id ;

				id = JOptionPane.showInputDialog(this, "Enter Score Id");

				if (id ==null || id.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(),"Please Enter Correct id.");
					   
				} 
				else 
				{
					
					Score obj = ScoreDAO.getByScoreID(id);
				        if (obj != null) {
			           // System.out.println(obj);
			            //table.clearSelection();
				        model.setRowCount(0);
				        model.addRow(new Object[] {obj.getScoreID(),obj.getStudentID(),obj.getCourseID(),obj.getCreditObtained(),obj.getDateOfExam()});
				        
			        } else {
			        	JOptionPane.showMessageDialog(getContentPane(),"Score with ID " + id + " not found.");
			        }
				}
			}
		});
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Deactivate Score By Id");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id ;

				id = JOptionPane.showInputDialog(this, "Enter Score Id");

				if (id ==null || id.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(),"Please Enter Correct id.");
					   
				} 
				else 
				{
					
					  boolean result = ScoreDAO.delete(id);
				        if (result) {
			        	JOptionPane.showMessageDialog(getContentPane(),"The score is successfully deleted.");
			        } else {
			        	JOptionPane.showMessageDialog(getContentPane(),"Something went wrong.");
			        }
				}
				
			
	
			}
		});
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Go Back");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     dispose();
			     new AdminMenu();
			}
		});
		panel.add(btnNewButton_4);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(250, 10, 525, 400);
		panel_1.setBorder(new LineBorder(SystemColor.textHighlight, 5));
		
		getContentPane().add(panel_1);
		
		model = new DefaultTableModel();
		Container cnt = this.getContentPane();
		model.addColumn("Score Id");
		model.addColumn("Student Id");
		model.addColumn("Course Id");
		model.addColumn("Credit Obtained");
		model.addColumn("Date Of Exam");
		
		table = new JTable(model);
		JScrollPane tableScrollPane = new JScrollPane();
		tableScrollPane.setBounds(10, 10, 500, 375);
		panel_1.add(tableScrollPane);
		//panel_1.add(table);
		tableScrollPane.setViewportView(table);
		
		JPanel coursePanel = new JPanel();
		coursePanel.setBorder(new LineBorder(SystemColor.textHighlight, 5));
		coursePanel.setBounds(10, 10, 240, 400);
		getContentPane().add(coursePanel);
		coursePanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Score Id");
		lblNewLabel.setBounds(10, 56, 96, 14);
		coursePanel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(129, 53, 96, 20);
		coursePanel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Student Id");
		lblNewLabel_1.setBounds(10, 108, 96, 14);
		coursePanel.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(129, 105, 96, 20);
		coursePanel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Course Id");
		lblNewLabel_2.setBounds(10, 158, 96, 14);
		coursePanel.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(129, 155, 96, 20);
		coursePanel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Score Detail");
		lblNewLabel_3.setBounds(61, 11, 123, 14);
		coursePanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Credit Obtained");
		lblNewLabel_4.setBounds(10, 213, 96, 14);
		coursePanel.add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(129, 210, 96, 20);
		coursePanel.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Date of Exam");
		lblNewLabel_5.setBounds(10, 267, 96, 14);
		coursePanel.add(lblNewLabel_5);
		
		 formattedTextField = new JFormattedTextField();
		formattedTextField.setBounds(129, 264, 96, 20);
		coursePanel.add(formattedTextField);
	}
}
