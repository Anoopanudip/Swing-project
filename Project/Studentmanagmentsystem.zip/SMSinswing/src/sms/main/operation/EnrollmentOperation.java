package sms.main.operation;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import sms.main.DAO.CourseDAO;
import sms.main.menu.AdminMenu;
import sms.main.model.Course;
import sms.main.DAO.EnrollmentDAO;
import sms.main.model.Enrollment;

public class EnrollmentOperation extends JFrame {

	private JTable table;
	DefaultTableModel model;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	public EnrollmentOperation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(10, 10, 800, 500);
		setVisible(true);

		JPanel panel = new JPanel();
		panel.setBounds(5, 400, 780, 60);
		panel.setBorder(new LineBorder(SystemColor.textHighlight, 5));
		
		getContentPane().add(panel);
		
		JButton btnNewButton_5 = new JButton("Add Enrollment");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enrollmentID=textField.getText();
				String studentID=textField_1.getText();
				String courseID=textField_2.getText();
				String instructorID=textField_3.getText();
				 Enrollment obj = new Enrollment(enrollmentID, studentID, courseID, instructorID);

			        // Calling method to insert into table and passing the object of Enrollment class
			        boolean result = EnrollmentDAO.insert(obj);
			    if (result) {
		        	JOptionPane.showMessageDialog(getContentPane()," The enrollment is successfully added.");
		           // System.out.println("To continue follow the steps...");
		        } else {
		        	JOptionPane.showMessageDialog(getContentPane(),"Something went wrong.");
		        }
			}
		});
		panel.add(btnNewButton_5);
		
		JButton btnNewButton = new JButton("Update Enrollment");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enrollmentID=textField.getText();
				String studentID=textField_1.getText();
				String courseID=textField_2.getText();
				String instructorID=textField_3.getText();
				  Enrollment obj = new Enrollment(enrollmentID, studentID, courseID, instructorID);

			        // Calling method to update the record in the table
			        boolean result = EnrollmentDAO.update(obj, enrollmentID);
			   	        if (result) {                        
			        	JOptionPane.showMessageDialog(getContentPane(),"The enrollment is successfully updated.");
			        } else {
			        	JOptionPane.showMessageDialog(getContentPane(),"Something went wrong.");
			        }  
			}
		});
		btnNewButton.setVerticalAlignment(SwingConstants.TOP);
		
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("View All Enrollment");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//table.clearSelection();
				model.setRowCount(0);
				 List<Enrollment> enrollments = EnrollmentDAO.getAllEnrollments();
			        for (Enrollment enrollment : enrollments) {
			        	//System.out.println(course);
		        	model.addRow(new Object[] {enrollment.getEnrollmentID(),enrollment.getStudentID(),enrollment.getCourseID(),enrollment.getInstructorID()});
		        }
			}
		});
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("View Enrollment By Id");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id ;

				id = JOptionPane.showInputDialog(this, "Enter Enrollment Id");

				if (id ==null || id.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(),"Please Enter Correct id.");
					   
				} 
				else 
				{
					
					 Enrollment obj = EnrollmentDAO.getByEnrollmentID(id);
				        if (obj != null) {
			            System.out.println(obj);
			           // table.clearSelection();
			            model.setRowCount(0);
				        model.addRow(new Object[] {obj.getEnrollmentID(),obj.getStudentID(),obj.getCourseID(),obj.getInstructorID()});
				        
			        } else {
			        	JOptionPane.showMessageDialog(getContentPane(),"Enrollment with ID " + id + " not found.");
			        }
				}
			}
		});
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete Enrollment By Id");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id ;

				id = JOptionPane.showInputDialog(this, "Enter Enrollment Id");

				if (id ==null || id.equals("")) {
					JOptionPane.showMessageDialog(getContentPane(),"Please Enter Correct id.");
					   
				} 
				else 
				{
					
					 boolean result = EnrollmentDAO.delete(id);
				        if (result) {
			        	JOptionPane.showMessageDialog(getContentPane(),"The enrollment is successfully deleted.");
			        } else {
			        	JOptionPane.showMessageDialog(getContentPane(),"Something went wrong.");
			        }
				}
				
			
	
			}
		});
		btnNewButton_3.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Go Back");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     dispose();
			     new AdminMenu();
			}
		});
		panel.add(btnNewButton_4);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(250, 10, 525, 400);
		panel_1.setBorder(new LineBorder(SystemColor.textHighlight, 5));
		
		getContentPane().add(panel_1);
		
		model = new DefaultTableModel();
		Container cnt = this.getContentPane();
		model.addColumn("Enrollment Id");
		model.addColumn("Student Id");
		model.addColumn("Course Id");
		model.addColumn("Instructor Id");
		table = new JTable(model);
		JScrollPane tableScrollPane = new JScrollPane();
		tableScrollPane.setBounds(10, 10, 500, 350);
		panel_1.add(tableScrollPane);
		//panel_1.add(table);
		tableScrollPane.setViewportView(table);
		
		JPanel coursePanel = new JPanel();
		coursePanel.setBorder(new LineBorder(SystemColor.textHighlight, 5));
		coursePanel.setBounds(10, 10, 240, 400);
		getContentPane().add(coursePanel);
		coursePanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enrollment Id");
		lblNewLabel.setBounds(10, 56, 96, 14);
		coursePanel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(129, 53, 96, 20);
		coursePanel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Student Id");
		lblNewLabel_1.setBounds(10, 108, 96, 14);
		coursePanel.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(129, 105, 96, 20);
		coursePanel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Course Id");
		lblNewLabel_2.setBounds(10, 158, 96, 14);
		coursePanel.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(129, 155, 96, 20);
		coursePanel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Enrollment Detail");
		lblNewLabel_3.setBounds(54, 11, 171, 14);
		coursePanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Instructor Id");
		lblNewLabel_4.setBounds(10, 208, 96, 14);
		coursePanel.add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(129, 205, 96, 20);
		coursePanel.add(textField_3);
		textField_3.setColumns(10);
	}
	

}
