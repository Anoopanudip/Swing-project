package sms.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import sms.main.connection.*;
import sms.main.menu.AdminMenu;
import sms.main.menu.InstructorMenu;
import sms.main.menu.StudentMenu;


public class Login extends JFrame implements ActionListener {
	JTextField uname,pwd;
	JButton login;
	Connection con;
	String username,password;
	private String roleName;
	public Login() {
		uname=new JTextField();
		pwd=new JTextField();
		login=new JButton("Login");
		
		uname.setBounds(100,100,150,40);
		pwd.setBounds(100,160,150,40);
		login.setBounds(120,220,100,40);
		
		login.addActionListener(this);
		setTitle("Login Form");
		add(login);
		add(uname);
		add(pwd);
		
		
		setSize(500,500);
		setLayout(null);
		setVisible(true);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		 username=uname.getText();
		 password=pwd.getText();
		
		try {
			con = SmsDBConnection.createC();
			Statement st = con.createStatement();

			

			String fetchQuery = "SELECT userType FROM Login WHERE username = '" + username + "' AND password = '"
					+ password + "'";

			ResultSet rs = st.executeQuery(fetchQuery);

			if (rs.next()) {
				roleName = rs.getString("userType");
				System.out.println("Login successful as " + roleName);
				System.out.println("Thankyou for Login.");
				if (roleName.equals("admin")) {
					dispose();
	                new AdminMenu();
	            } else if (roleName.equals("instructor")) {
	                dispose();
	            	new InstructorMenu();
	            } else if (roleName.equals("student")) {
	            	dispose();
	            	new StudentMenu();
			     }
			}
			else {
				//System.out.println("Wrong credentials. Please check the username and password.");
				JOptionPane.showMessageDialog(this,"Wrong credentials. Please check the username and password.");
				dispose();
				new Login();
			}

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}

}
