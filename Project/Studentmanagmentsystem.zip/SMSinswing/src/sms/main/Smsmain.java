package sms.main;

public class Smsmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login login=new Login();
	}

}
